
import React from 'react';

interface AdPlaceholderProps {
  type: 'banner' | 'native' | 'sidebar';
  className?: string;
}

export const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ type, className = '' }) => {
  const heights = {
    banner: 'h-24',
    native: 'h-64',
    sidebar: 'h-[400px]'
  };

  return (
    <div className={`flex flex-col items-center justify-center border border-dashed border-slate-700 bg-slate-900/50 rounded-xl overflow-hidden ${heights[type]} ${className}`}>
      <span className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Advertisement</span>
      <div className="text-slate-600 italic text-sm text-center px-4">
        {type === 'banner' && "Horizontal Ad Space - Place Monetag Script Here"}
        {type === 'native' && "Native Ad Content Area"}
        {type === 'sidebar' && "Vertical Sidebar Ads"}
      </div>
      {/* 
        In production, replace this div with Monetag script like:
        <script async data-cfasync="false" src="//..."></script>
      */}
    </div>
  );
};
