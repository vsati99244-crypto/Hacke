
export enum AppTab {
  CHAT = 'chat',
  IMAGES = 'images',
  VIDEOS = 'videos',
  SETTINGS = 'settings'
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: Date;
}

export interface GeneratedVideo {
  id: string;
  url: string;
  prompt: string;
  timestamp: Date;
}
