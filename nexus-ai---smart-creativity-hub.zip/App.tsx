
import React, { useState, useEffect, useRef } from 'react';
import { AppTab, Message, GeneratedImage, GeneratedVideo } from './types';
import { chatWithGemini, generateImage, generateVideo } from './services/geminiService';
import { AdPlaceholder } from './components/AdPlaceholder';
import { 
  ChatBubbleLeftRightIcon, 
  PhotoIcon, 
  VideoCameraIcon, 
  ArrowPathIcon,
  PaperAirplaneIcon,
  SparklesIcon,
  CpuChipIcon,
  CommandLineIcon,
  ArrowDownTrayIcon
} from '@heroicons/react/24/outline';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.CHAT);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [videos, setVideos] = useState<GeneratedVideo[]>([]);
  const [loading, setLoading] = useState(false);
  const [videoStatus, setVideoStatus] = useState('');
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSendMessage = async () => {
    if (!input.trim() || isTyping) return;
    
    const userMsg: Message = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      const reply = await chatWithGemini(input, history);
      const botMsg: Message = { role: 'model', text: reply, timestamp: new Date() };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', text: "Service temporarily unavailable. Please check your connection.", timestamp: new Date() }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    try {
      const url = await generateImage(input);
      const newImg: GeneratedImage = {
        id: Date.now().toString(),
        url,
        prompt: input,
        timestamp: new Date()
      };
      setImages(prev => [newImg, ...prev]);
      setInput('');
    } catch (err) {
      alert("Image generation failed. Try a different prompt.");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateVideo = async () => {
    // Paid key selection check for Veo models
    const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
    if (!hasKey) {
      alert("AI Video generation requires a billing-enabled API key. Opening selector...");
      await (window as any).aistudio?.openSelectKey();
      return;
    }

    if (!input.trim() || loading) return;
    setLoading(true);
    setVideoStatus('Initializing Cinematic Engine...');
    
    try {
      const url = await generateVideo(input);
      const newVid: GeneratedVideo = {
        id: Date.now().toString(),
        url,
        prompt: input,
        timestamp: new Date()
      };
      setVideos(prev => [newVid, ...prev]);
      setInput('');
    } catch (err) {
      console.error(err);
      alert("Video generation encountered an error. Ensure your selected project has Veo access.");
    } finally {
      setLoading(false);
      setVideoStatus('');
    }
  };

  const currentAction = activeTab === AppTab.CHAT ? handleSendMessage : 
                        activeTab === AppTab.IMAGES ? handleGenerateImage : 
                        handleGenerateVideo;

  return (
    <div className="flex flex-col h-screen bg-[#020617] text-slate-200 overflow-hidden">
      {/* Header */}
      <header className="px-6 py-4 flex items-center justify-between glass-card border-b border-white/5 z-50">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/30">
            <CpuChipIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter text-white">
              NEXUS<span className="text-indigo-400">AI</span>
            </h1>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Creative Powerhouse</p>
          </div>
        </div>
        
        <nav className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-2xl border border-white/5">
          {[
            { id: AppTab.CHAT, icon: ChatBubbleLeftRightIcon, label: 'Chat', color: 'blue' },
            { id: AppTab.IMAGES, icon: PhotoIcon, label: 'Art', color: 'purple' },
            { id: AppTab.VIDEOS, icon: VideoCameraIcon, label: 'Motion', color: 'pink' }
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all duration-300 font-semibold text-sm ${
                activeTab === tab.id 
                ? `bg-indigo-600 text-white shadow-xl shadow-indigo-500/20` 
                : 'hover:bg-slate-800 text-slate-400'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="hidden md:inline">{tab.label}</span>
            </button>
          ))}
        </nav>

        <div className="hidden lg:block">
           <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-xs font-bold text-emerald-500 uppercase">System Online</span>
           </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Ad (Hidden on mobile) */}
        <aside className="hidden xl:flex w-64 p-4 border-r border-white/5 flex-col gap-4 overflow-y-auto">
          <AdPlaceholder type="sidebar" />
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/5">
             <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Recent Prompts</h3>
             <div className="space-y-2">
                {images.slice(0, 3).map(img => (
                  <p key={img.id} className="text-xs text-slate-400 truncate bg-slate-800/50 p-2 rounded-lg">{img.prompt}</p>
                ))}
             </div>
          </div>
          <AdPlaceholder type="sidebar" className="mt-auto" />
        </aside>

        {/* Content Area */}
        <main className="flex-1 flex flex-col min-w-0 bg-[#020617] relative">
          {/* Top Banner Ad */}
          <div className="px-4 pt-4">
             <AdPlaceholder type="banner" className="mb-2" />
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar" ref={scrollRef}>
            {activeTab === AppTab.CHAT && (
              <div className="max-w-4xl mx-auto p-4 md:p-8 space-y-6">
                {messages.length === 0 && (
                  <div className="py-20 flex flex-col items-center text-center">
                    <div className="w-24 h-24 bg-indigo-500/10 rounded-3xl flex items-center justify-center mb-6 border border-indigo-500/20">
                      <SparklesIcon className="w-12 h-12 text-indigo-400" />
                    </div>
                    <h2 className="text-3xl font-bold text-white mb-2">How can I help you today?</h2>
                    <p className="text-slate-400 max-w-md">Nexus AI can write code, analyze data, or just have a conversation. Try asking about something complex!</p>
                  </div>
                )}
                {messages.map((m, idx) => (
                  <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
                    <div className={`max-w-[85%] px-6 py-4 rounded-3xl ${
                      m.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-500/10' 
                      : 'bg-slate-900/80 border border-white/10 text-slate-100 rounded-tl-none'
                    }`}>
                      <div className="text-[10px] font-bold uppercase tracking-widest mb-1.5 opacity-60">
                        {m.role === 'user' ? 'Direct Input' : 'Nexus Intelligence'}
                      </div>
                      <div className="whitespace-pre-wrap leading-relaxed text-[15px]">{m.text}</div>
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-slate-900/80 border border-white/10 px-6 py-4 rounded-3xl rounded-tl-none flex items-center gap-3">
                      <div className="flex gap-1">
                        <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                        <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                      </div>
                      <span className="text-xs font-medium text-slate-400 uppercase tracking-widest">Processing</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {(activeTab === AppTab.IMAGES || activeTab === AppTab.VIDEOS) && (
              <div className="p-4 md:p-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* Generation Placeholder */}
                  {loading && (
                    <div className="aspect-video sm:aspect-square bg-slate-900/50 rounded-3xl flex flex-col items-center justify-center border border-white/5 animate-pulse">
                      <ArrowPathIcon className="w-12 h-12 text-indigo-500 animate-spin mb-4" />
                      <p className="text-indigo-400 font-bold text-xs uppercase tracking-widest">{videoStatus || 'Generating Asset...'}</p>
                    </div>
                  )}

                  {/* Images Display */}
                  {activeTab === AppTab.IMAGES && images.map(img => (
                    <div key={img.id} className="group relative overflow-hidden rounded-3xl bg-slate-900 border border-white/5 aspect-square">
                      <img src={img.url} alt={img.prompt} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                        <p className="text-sm text-white line-clamp-2 mb-3 font-medium">{img.prompt}</p>
                        <a href={img.url} download={`nexus-ai-${img.id}.png`} className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded-xl text-xs font-bold transition-colors">
                          <ArrowDownTrayIcon className="w-4 h-4" />
                          Download HQ
                        </a>
                      </div>
                    </div>
                  ))}

                  {/* Videos Display */}
                  {activeTab === AppTab.VIDEOS && videos.map(vid => (
                    <div key={vid.id} className="group relative overflow-hidden rounded-3xl bg-slate-900 border border-white/5 aspect-video sm:aspect-square">
                      <video src={vid.url} controls className="w-full h-full object-cover" />
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <a href={vid.url} download={`nexus-ai-${vid.id}.mp4`} className="p-2 bg-black/50 backdrop-blur-md rounded-lg hover:bg-indigo-600 transition-colors">
                            <ArrowDownTrayIcon className="w-5 h-5 text-white" />
                         </a>
                      </div>
                    </div>
                  ))}
                </div>
                {((activeTab === AppTab.IMAGES && images.length === 0 && !loading) || (activeTab === AppTab.VIDEOS && videos.length === 0 && !loading)) && (
                   <div className="py-20 flex flex-col items-center text-center opacity-40">
                      <CommandLineIcon className="w-16 h-16 mb-4" />
                      <p className="text-xl font-medium tracking-tight">Your creative gallery is empty.</p>
                      <p className="text-sm">Enter a detailed prompt below to start generating.</p>
                   </div>
                )}
              </div>
            )}
          </div>

          {/* Bottom Ad Space */}
          <div className="px-4">
             <AdPlaceholder type="banner" className="mb-4" />
          </div>

          {/* Input Area */}
          <footer className="p-4 md:p-6 bg-[#020617]/80 backdrop-blur-xl border-t border-white/5">
            <div className="max-w-4xl mx-auto relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-3xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000"></div>
              <div className="relative flex items-end gap-3 bg-slate-900/90 border border-white/10 rounded-[28px] p-2 pl-6 shadow-2xl">
                <textarea
                  rows={1}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      currentAction();
                    }
                  }}
                  placeholder={
                    activeTab === AppTab.CHAT ? "Ask Nexus anything..." :
                    activeTab === AppTab.IMAGES ? "Describe the art you want to create..." :
                    "Describe the motion scene to generate..."
                  }
                  className="flex-1 bg-transparent border-none focus:ring-0 text-slate-100 placeholder-slate-500 py-3 resize-none max-h-32 text-[15px] leading-relaxed"
                />
                <button
                  onClick={currentAction}
                  disabled={!input.trim() || loading || isTyping}
                  className={`p-3 rounded-2xl transition-all duration-300 ${
                    !input.trim() || loading || isTyping 
                    ? 'bg-slate-800 text-slate-600' 
                    : 'bg-indigo-600 text-white hover:scale-105 active:scale-95 shadow-lg shadow-indigo-500/20'
                  }`}
                >
                  {loading || isTyping ? (
                    <ArrowPathIcon className="w-6 h-6 animate-spin" />
                  ) : (
                    <PaperAirplaneIcon className="w-6 h-6" />
                  )}
                </button>
              </div>
              <p className="text-[10px] text-center text-slate-500 mt-3 font-medium uppercase tracking-[0.2em]">
                Powered by Gemini 3 Pro & Veo Vision • 100% Secure & Fast
              </p>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
};

export default App;
